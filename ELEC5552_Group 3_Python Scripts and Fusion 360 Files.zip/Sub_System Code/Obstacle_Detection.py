import RPi.GPIO as GPIO
import time

# Set GPIO mode
GPIO.setmode(GPIO.BCM)

# Define GPIO pins for the ultrasonic sensor
TRIG = 23
ECHO = 24

# Set up GPIO pins as input/output
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

def measure_distance():
    """
    Measures the distance using an ultrasonic sensor.
    Returns the distance in cm.
    """
    # Ensure the trigger is low
    GPIO.output(TRIG, False)
    time.sleep(0.002)  # Wait for 2 ms

    # Send a 10us pulse to trigger
    GPIO.output(TRIG, True)
    time.sleep(0.00001)  # 10 microseconds
    GPIO.output(TRIG, False)

    # Measure the time until the echo is received
    pulse_start = time.time()
    while GPIO.input(ECHO) == GPIO.LOW:
        pulse_start = time.time()

    pulse_end = time.time()
    while GPIO.input(ECHO) == GPIO.HIGH:
        pulse_end = time.time()

    # Calculate the pulse duration
    pulse_duration = pulse_end - pulse_start

    # Calculate the distance (Speed of sound is 34300 cm/s)
    distance = pulse_duration * 17150
    distance = round(distance, 2)

    return distance

def adjust_for_obstacle(current_distance, min_distance=20, max_distance=50):
    """
    If the distance is below 50 cm, the drone will stop all movement (set pitch, yaw, roll to zero).
    """
    yaw, pitch, roll = 0, 0, 0  # Set yaw, pitch, and roll to zero when hovering

    if min_distance <= current_distance <= max_distance:
        # Within safe distance, hover (stop all movement)
        print(f"Holding position. Safe distance from obstacle. Yaw: {yaw}, Pitch: {pitch}, Roll: {roll}")
        obstacle_detection = True
    else:
        # No obstacle detected, normal operation
        obstacle_detection = False
        print(f"No obstacle detected. Resuming normal operation.")

    return obstacle_detection

try:
    obstacle_timer = 0  # To track the duration of no obstacle detection
    obstacle_cleared = False  # Indicates if the obstacle has been cleared

    while True:
        # Measure distance to the nearest object
        dist = measure_distance()
        print(f"Measured Distance = {dist} cm")

        # Adjust behavior based on distance
        obstacle_detection = adjust_for_obstacle(dist)

        # If no obstacle is detected (distance > 50 cm), start counting how long it's been cleared
        if dist > 50:  # No obstacle detected
            if obstacle_cleared:
                # Continue counting if the obstacle was already cleared
                obstacle_timer += 0.5
            else:
                # Start counting from zero if obstacle is newly cleared
                obstacle_timer = 0.5
                obstacle_cleared = True
        else:
            # Reset timer if an obstacle is detected again
            obstacle_timer = 0
            obstacle_cleared = False

        # If obstacle has been cleared for more than 10 seconds, resume normal operation
        if obstacle_cleared and obstacle_timer >= 10:
            print("Obstacle cleared for more than 3 seconds. Resuming normal operation.")
            obstacle_detection = False  # Resume normal flight

        # Wait for 0.5 seconds before taking the next measurement
        time.sleep(0.5)

except KeyboardInterrupt:
    print("Measurement stopped by user")
    GPIO.cleanup()
