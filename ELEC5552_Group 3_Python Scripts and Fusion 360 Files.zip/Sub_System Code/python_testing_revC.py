import serial
import struct
import time

# Initialize UART communication for RC commands (UART1 on GPIO)
ser_rc = serial.Serial('/dev/serial0', 115200, timeout=1)  

# Initialize UART communication for MSP requests (UART2 via USB to UART TTL converter)
ser_msp = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)  

# Define MSP header
MSP_HEADER = b'$M<'
MSP_HEADER_RESPONSE = b'$M>'

# Initialize armingDisableFlags
armingDisableFlags = 0  # Global variable to store arming disable flags

# Create MSP message with payload
def create_msp_message(command, payload=b''):
    size = len(payload)
    checksum = 0
    checksum ^= size
    checksum ^= command
    for b in payload:
        checksum ^= b
    return MSP_HEADER + struct.pack('<BB', size, command) + payload + struct.pack('<B', checksum & 0xFF)

# Send MSP_SET_RAW_RC command with RC channel values via ser_rc (UART1)
def send_rc_command(channels):
    command = 200  # MSP_SET_RAW_RC
    payload = struct.pack('<8H', *channels)
    message = create_msp_message(command, payload)
    ser_rc.write(message)
    ser_rc.flush()  # Ensure data is sent promptly

# Send MSP_STATUS_EX request to get arming disable flags via ser_msp (UART2)
def send_msp_status_ex_request():
    command = 150  # MSP_STATUS_EX
    message = create_msp_message(command)
    ser_msp.write(message)
    ser_msp.flush()

# Buffer to accumulate incoming serial data
data_buffer = b''

# Process serial data and extract MSP messages
def process_serial_data(data):
    global data_buffer
    data_buffer += data

    while True:
        # Look for the MSP header in the data_buffer
        header_index = data_buffer.find(MSP_HEADER_RESPONSE)
        if header_index == -1:
            # No header found, keep the last few bytes in case header is split
            data_buffer = data_buffer[-2:]
            break
        else:
            # Remove data before the header
            if header_index > 0:
                data_buffer = data_buffer[header_index:]

            # Check if we have enough data for size, command, and checksum
            if len(data_buffer) < 6:
                # Not enough data yet
                break

            # Extract size and command
            size = data_buffer[3]
            command = data_buffer[4]

            total_length = 3 + 1 + 1 + size + 1  # header + size + command + payload + checksum

            if len(data_buffer) < total_length:
                # Not enough data yet
                break

            # Extract the full message
            message = data_buffer[:total_length]
            # Remove the message from the buffer
            data_buffer = data_buffer[total_length:]

            # Now process the message
            parse_msp_message(message)

# Process MSP_STATUS_EX messages received via UART2
def parse_msp_status_ex(message):
    global armingDisableFlags

    size = message[3]
    payload = message[5:5+size]

    # Print raw payload data
    print(f"Payload length: {len(payload)}")
    print(f"Payload in hex: {payload.hex()}")

    if len(payload) == 22:
        try:
            # Unpack the 22-byte payload
            unpacked = struct.unpack('<HHHI B H H I H B', payload)
            cycleTime = unpacked[0]
            i2cErrorCounter = unpacked[1]
            activeSensors = unpacked[2]
            modeFlags = unpacked[3]
            profile = unpacked[4]
            systemLoad = unpacked[5]
            gyroCycleTime = unpacked[6]
            armingDisableFlags = unpacked[7]
            spare = unpacked[8]
            status = unpacked[9]

            print(f"Cycle Time: {cycleTime}")
            print(f"I2C Error Counter: {i2cErrorCounter}")
            print(f"Active Sensors: {activeSensors}")
            print(f"Mode Flags: {modeFlags} (binary: {modeFlags:032b})")
            print(f"Profile: {profile}")
            print(f"System Load: {systemLoad}")
            print(f"Gyro Cycle Time: {gyroCycleTime}")
            print(f"Arming Disable Flags: {armingDisableFlags} (binary: {armingDisableFlags:032b})")
            print(f"Spare: {spare}")
            print(f"Status: {status}")

            # Interpret arming disable flags
            interpret_arming_disable_flags(armingDisableFlags)

            # Check arming status based on modeFlags
            if modeFlags & (1 << 0):
                print("Flight Controller is ARMED")
            else:
                print("Flight Controller is DISARMED")

            # Check if ANGLE mode is active
            if modeFlags & (1 << 1):
                print("ANGLE Mode is ACTIVE")
            else:
                print("ANGLE Mode is INACTIVE")

        except struct.error as e:
            print(f"Struct unpacking error: {e}")
    else:
        print(f"Unexpected payload length: {len(payload)}")

def parse_msp_message(message):
    # message is a full MSP message starting with $M>
    if len(message) < 6:
        # Invalid message length
        return

    if message[:3] != MSP_HEADER_RESPONSE:
        return

    size = message[3]
    command = message[4]
    payload = message[5:5+size]
    checksum = message[5+size]

    # Verify checksum
    checksum_calc = 0
    checksum_calc ^= size
    checksum_calc ^= command
    for b in payload:
        checksum_calc ^= b
    checksum_calc &= 0xFF

    if checksum != checksum_calc:
        print("Checksum mismatch")
        return

    # Ignore empty responses for MSP_SET_RAW_RC
    if command == 200 and size == 0:
        # Silently ignore to avoid cluttering output
        return

    # Process known commands
    if command == 150:  # MSP_STATUS_EX
        parse_msp_status_ex(message)
    else:
        print(f"Received message with command {command}, but no handler is implemented for it.")

# Interpret arming disable flags
def interpret_arming_disable_flags(flags):
    arming_disable_flags = [
        (1 << 0, "ARMING_DISABLED_NO_GYRO"),
        (1 << 1, "ARMING_DISABLED_FAILSAFE"),
        (1 << 2, "ARMING_DISABLED_RX_FAILSAFE"),
        (1 << 3, "ARMING_DISABLED_BAD_RX_RECOVERY"),
        (1 << 4, "ARMING_DISABLED_BOXFAILSAFE"),
        (1 << 5, "ARMING_DISABLED_RUNAWAY_TAKEOFF"),
        (1 << 6, "ARMING_DISABLED_THROTTLE"),
        (1 << 7, "ARMING_DISABLED_ANGLE"),
        (1 << 8, "ARMING_DISABLED_BOOT_GRACE_TIME"),
        (1 << 9, "ARMING_DISABLED_NOPREARM"),
        (1 << 10, "ARMING_DISABLED_LOAD"),
        (1 << 11, "ARMING_DISABLED_CALIBRATING"),
        (1 << 12, "ARMING_DISABLED_CLI"),
        (1 << 13, "ARMING_DISABLED_CMS_MENU"),
        (1 << 14, "ARMING_DISABLED_BST"),
        (1 << 15, "ARMING_DISABLED_MSP"),
        (1 << 16, "ARMING_DISABLED_PARALYZE"),
        (1 << 17, "ARMING_DISABLED_GPS"),
        (1 << 18, "ARMING_DISABLED_RESC"),
        (1 << 19, "ARMING_DISABLED_RPMFILTER"),
        (1 << 20, "ARMING_DISABLED_REBOOT_REQUIRED"),
        (1 << 21, "ARMING_DISABLED_DSHOT_BITBANG"),
        (1 << 22, "ARMING_DISABLED_ACC_CALIBRATION"),
        (1 << 23, "ARMING_DISABLED_MOTOR_PROTOCOL"),
        (1 << 24, "ARMING_DISABLED_ARM_SWITCH"),
        (1 << 25, "ARMING_DISABLED_TEST_MODE"),
    ]

    if flags == 0:
        print("No arming disable flags are active.")
    else:
        print("Arming Disable Flags:")
        for flag_value, flag_name in arming_disable_flags:
            if flags & flag_value:
                print(f" - {flag_name}")


# Main function to send RC commands via UART1 and retrieve telemetry via UART2
def main():
    # Set up the RC channel values (channels 1-8)
    channels = [1500] * 8  # Initialize all channels to mid-point (1500)
    channels[0] = 1000     # Throttle at minimum (Channel 1)
    channels[1] = 1500     # Roll (Aileron)
    channels[2] = 1500     # Pitch (Elevator)
    channels[3] = 1500     # Yaw (Rudder)
    channels[4] = 1000     # AUX1 (ARM switch) to "off" position at startup
    channels[5] = 1000     # AUX2 (ANGLE mode) to active value (Channel 6)

    print("Initializing arm switch to 'off' to clear BAD_RX_RECOVERY flag...")

    global data_buffer
    data_buffer = b''

    last_status_time = 0

    # Send RC commands with arm switch off for 2 seconds via UART1
    start_time = time.time()
    while time.time() - start_time < 2:
        send_rc_command(channels)
        time.sleep(0.02)  # Maintain loop rate of approximately 50Hz

    # Proceed with the main loop
    try:
        # Continuously send RC commands via UART1
        while True:
            send_rc_command(channels)

            # Read any available data from UART2 (MSP)
            data = ser_msp.read(ser_msp.in_waiting or 1)
            if data:
                process_serial_data(data)

            # Send MSP_STATUS_EX request every second via UART2
            current_time = time.time()
            if current_time - last_status_time >= 1:
                send_msp_status_ex_request()
                last_status_time = current_time

            time.sleep(0.02)  # Maintain loop rate of approximately 50Hz

    except KeyboardInterrupt:
        print("KeyboardInterrupt detected. Disarming before exiting...")
        # Set arm switch to "off"
        channels[4] = 1000  # Set AUX1 to "off" position

        # Send RC commands with arm switch off for 0.5 seconds via UART1
        disarm_time = time.time()
        while time.time() - disarm_time < 0.5:
            send_rc_command(channels)
            time.sleep(0.02)

        print("Disarmed. Exiting...")
        ser_rc.close()
        ser_msp.close()

if __name__ == '__main__':
    main()
