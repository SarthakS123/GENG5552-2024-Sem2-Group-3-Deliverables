import subprocess
import time
import keyboard  # Module to handle keyboard input

# Initial RC values
pitch = 1500  # Pitch remains neutral
roll = 1500   # Roll remains neutral
yaw = 1500
throttle = 1500
arm = 1000  # Disarmed by default
Manual_Override = False

# Constants for RC limits
RC_MIN = 1000
RC_MAX = 2000
NEUTRAL = 1500
THROTTLE_UP = 1600  # Ascend
THROTTLE_DOWN = 1400  # Descend
THROTTLE_NEUTRAL = 1500  # Hover

# Function to print current RC values
def print_rc_values():
    print(f"Pitch: {pitch}, Roll: {roll}, Yaw: {yaw}, Throttle: {throttle}, Arm: {arm}")
    print(f"Manual Override: {Manual_Override}")

# Function to perform emergency stop
def emergency_stop():
    global pitch, roll, yaw, throttle, arm, Manual_Override
    pitch = NEUTRAL
    roll = NEUTRAL
    yaw = NEUTRAL
    throttle = 1000  # Minimum throttle
    arm = 1000  # Disarm
    Manual_Override = False  # Deactivate manual override
    print("Emergency Stop Activated")

# Function to ping the host (Raspberry Pi)
def ping(host):
    try:
        # Execute the ping command
        result = subprocess.run(['ping', '-n', '1', host], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        if "Reply from" in result.stdout and "unreachable" not in result.stdout:
            return True
        else:
            return False
    except subprocess.CalledProcessError as e:
        print(f"Ping failed with error: {e.output}")
    return False

# Main control loop
try:
    last_successful_ping = time.time()
    connection_lost_start = None

    while True:
        # Check connection status
        if ping(host):
            print(f"Connection to {host} is active.")
            last_successful_ping = time.time()  # Update the last successful ping time
            connection_lost_start = None  # Reset connection lost timer
        else:
            print("Ping failed.")
            if connection_lost_start is None:
                connection_lost_start = time.time()  # Start connection lost timer
            elif time.time() - connection_lost_start > 30:  # 30 seconds threshold
                print("Connection lost for more than 30 seconds. Executing emergency stop.")
                emergency_stop()
                break  # Exit the loop after emergency stop

        # Manual override is active
        Manual_Override = True

        # Yaw Left (A)
        if keyboard.is_pressed('a'):
            yaw = 1400  # Rotate counterclockwise
        else:
            yaw = NEUTRAL  # Reset to neutral when not pressed

        # Yaw Right (D)
        if keyboard.is_pressed('d'):
            yaw = 1600  # Rotate clockwise
        else:
            yaw = NEUTRAL  # Reset to neutral when not pressed

        # Throttle Up (Up arrow)
        if keyboard.is_pressed('up'):
            throttle = THROTTLE_UP  # Ascend
        
        # Throttle Down (Down arrow)
        if keyboard.is_pressed('down'):
            throttle = THROTTLE_DOWN  # Descend
        else:
            throttle = THROTTLE_NEUTRAL  # Hover (neutral throttle)

        # Emergency Stop (ESC)
        if keyboard.is_pressed('esc'):
            emergency_stop()
            break  # Stop the script

        # Print RC values periodically
        print_rc_values()
        time.sleep(0.1)  # Adjust loop speed

except KeyboardInterrupt:
    print("Manual Override stopped by user")
