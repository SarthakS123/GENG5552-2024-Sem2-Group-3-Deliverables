import cv2
import numpy as np
import time
from subprocess import run

# Function to determine the required yaw
def determine_yaw(cx, img_center_x):
    dx = cx - img_center_x  # Horizontal distance

    # Calculate yaw adjustments based on dx (yaw changes to rotate the drone)
    yaw = 1500 + int(dx * 0.1)  # Adjust the scaling factor as needed (1500 is neutral yaw)

    # Constrain yaw to valid RC values (1000 - 2000)
    yaw = max(1000, min(2000, yaw))
    return yaw

# Function to check if the detected line is vertical or perpendicular
def check_line_orientation(contour):
    x, y, w, h = cv2.boundingRect(contour)
    
    # Check if it's a vertical line (height > width) or horizontal (perpendicular) line (width > height)
    if h > w:
        return "vertical"
    elif w > h:
        return "perpendicular"
    else:
        return "unknown"

# Function to capture image using libcamera
def capture_image(filename='image.jpg'):
    # Capture the image using libcamera
    run(["libcamera-still", "-o", filename, "--nopreview", "--timeout", "1"], check=True)

# Initialize last detection time for parallel line
last_parallel_line_time = 0
parallel_line_cooldown = 2  # Time in seconds to ignore parallel lines after detection

# Capture images every 0.5 seconds and process them
while True:
    capture_image('image.jpg')  # Capture an image every 0.5 seconds
    image = cv2.imread('image.jpg')

    if image is None:
        print("Error: Image not loaded. Please check the file path and try again.")
        continue
    else:
        # Rotate the image 180 degrees to correct the orientation
        image = cv2.rotate(image, cv2.ROTATE_180)

        # Zoom out by resizing the image (e.g., to 25% of its original size)
        scale_percent = 25  # Scale to 25% of the original size
        width = int(image.shape[1] * scale_percent / 100)
        height = int(image.shape[0] * scale_percent / 100)
        dim = (width, height)

        # Calculate the center of the bottom edge of the image
        img_center_x = width // 2  # Midpoint of the bottom edge (x-coordinate)
        img_center_y = height  # Bottom of the image (y-coordinate)

        # Resize the image
        resized_image = cv2.resize(image, dim)

        # Convert the resized image to grayscale
        grayscale_image = cv2.cvtColor(resized_image, cv2.COLOR_BGR2GRAY)

        # Apply a manual threshold to focus on the darkest/high contrast areas
        manual_threshold = 40  # Adjust this value depending on the contrast of the line
        _, binary_image = cv2.threshold(grayscale_image, manual_threshold, 255, cv2.THRESH_BINARY_INV)

        # Apply morphological operations to connect broken parts of the line
        kernel = np.ones((7, 7), np.uint8)
        morph_image = cv2.morphologyEx(binary_image, cv2.MORPH_CLOSE, kernel)
        morph_image = cv2.dilate(morph_image, kernel, iterations=1)

        # Detect the line using contours
        contours, _ = cv2.findContours(morph_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # Initialize RC values
        pitch = 1600
        roll = 1500
        yaw = 1500
        AUX1 = 1500  # Arm by default, AUX1 = 1000 for disarm

        if contours:
            min_contour_area = 20  # Minimum area threshold
            filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > min_contour_area]

            for contour in filtered_contours:
                orientation = check_line_orientation(contour)

                # Check if enough time has passed since last parallel line detection
                current_time = time.time()

                if orientation == "vertical":
                    # If a vertical line is detected, continue tracking
                    print("Vertical line detected.")

                    # Calculate the center of the vertical contour
                    M = cv2.moments(contour)
                    if M['m00'] != 0:
                        cx = int(M['m10'] / M['m00'])
                        cy = int(M['m01'] / M['m00'])
                    else:
                        cx, cy = 0, 0

                    # Print the center coordinates
                    print(f"Center of the vertical line: ({cx}, {cy})")
                    print(f"Center of the image's bottom edge: ({img_center_x}, {img_center_y})")

                    # Calculate required yaw
                    yaw = determine_yaw(cx, img_center_x)

                    # Set pitch and roll to constant values
                    pitch = 1600  # Constant forward pitch
                    roll = 1500   # Neutral roll

                    # Print the required yaw, constant pitch, and roll
                    print(f"Pitch: {pitch}, Roll: {roll}, Yaw: {yaw}")

                elif orientation == "perpendicular" and (current_time - last_parallel_line_time) > parallel_line_cooldown:
                    # If a perpendicular line is detected and cooldown has passed, hover for 5 seconds
                    print("Perpendicular line detected. Hovering for 5 seconds.")

                    pitch = 1500
                    roll = 1500
                    yaw = 1500  # Neutral
                    time.sleep(5)  # Hold position for 5 seconds
                    print("Resuming after 5 seconds.")
                    
                    # Update the time of last parallel line detection
                    last_parallel_line_time = current_time

        else:
            # No line detected, set all values to neutral for 30 seconds, then disarm (set RC values to 0)
            print("No line detected. Setting neutral values for 30 seconds.")
            pitch = 1500
            roll = 1500
            yaw = 1500
            AUX1 = 1500  # Keep drone armed

            time.sleep(30)  # Hover for 30 seconds

            pitch = roll = yaw = 0  # Set RC values to 0 (disarm)
            AUX1 = 1000  # Disarm
            print("RC values set to 0. Disarmed due to no line detection.")

    # Wait for 0.5 seconds before capturing the next image
    time.sleep(0.5)
