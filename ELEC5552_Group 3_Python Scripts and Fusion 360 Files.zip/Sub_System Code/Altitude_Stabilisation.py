import RPi.GPIO as GPIO
import time

# Set GPIO mode
GPIO.setmode(GPIO.BCM)

# Define GPIO pins for the sensor
TRIG = 22
ECHO = 27

# Set up GPIO pins as input/output
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)

# Define the flag
change_altitude = True  # Starts as True because the altitude is not set

def measure_distance():
    # Ensure the trigger is low
    GPIO.output(TRIG, False)
    time.sleep(0.002)  # Wait for 2 ms

    # Send a 10us pulse to trigger
    GPIO.output(TRIG, True)
    time.sleep(0.00001)  # 10 microseconds
    GPIO.output(TRIG, False)

    # Measure the time until the echo is received
    pulse_start = time.time()
    while GPIO.input(ECHO) == GPIO.LOW:
        pulse_start = time.time()

    pulse_end = time.time()
    while GPIO.input(ECHO) == GPIO.HIGH:
        pulse_end = time.time()

    # Calculate the time difference
    pulse_duration = pulse_end - pulse_start

    # Calculate distance (Speed of sound is 34300 cm/s)
    distance = pulse_duration * 17150
    distance = round(distance, 2)

    return distance

def adjust_throttle(current_distance, target_altitude):
    """
    Adjusts the throttle based on the current altitude.
    Throttle is set to 1000 initially and is reduced as the drone approaches the target altitude.
    """
    global change_altitude  # Access the global flag

    # Altitude control logic
    if current_distance < target_altitude - 10:  # Below the target altitude minus drift
        throttle = 1600  # Increase throttle to ascend
        change_altitude = True  # Still adjusting altitude
    elif current_distance > target_altitude + 10:  # Above the target altitude plus drift
        throttle = 1400  # Decrease throttle to descend
        change_altitude = True  # Still adjusting altitude
    else:
        throttle = 1500  # Maintain a neutral throttle to hover at the target altitude
        change_altitude = False  # Altitude is now set

    return throttle

try:
    # Ask the user to input the desired altitude in cm
    target_altitude = float(input("Enter the desired altitude in cm: "))

    # Main control loop
    while True:
        # Measure the current altitude
        current_altitude = measure_distance()
        print(f"Current Altitude: {current_altitude} cm")

        # Adjust throttle based on current altitude
        throttle = adjust_throttle(current_altitude, target_altitude)
        print(f"Throttle output: {throttle}")

        # Display the status of the altitude flag
        if change_altitude:
            print("Altitude not reached, adjusting...")
        else:
            print("Altitude reached.")

        # Here you would send the throttle value to the flight controller
        # e.g. send_msp_rc_command([throttle, ...]) - Placeholder for sending RC values

        time.sleep(0.5)  # Wait for 0.5 seconds before the next measurement

except KeyboardInterrupt:
    print("Measurement stopped by user")
    GPIO.cleanup()
