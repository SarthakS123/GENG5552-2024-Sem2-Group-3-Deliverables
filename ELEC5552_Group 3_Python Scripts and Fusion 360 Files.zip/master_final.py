import threading
import time
import RPi.GPIO as GPIO
import cv2
import numpy as np
from subprocess import run
import sys
import select
import serial
import struct

# -------------------- Shared Variables and Flags --------------------

# Shared RC values
RC_values = {
    'throttle': 1000,  # Minimum throttle at start
    'yaw': 1500,
    'pitch': 1500,
    'roll': 1500,
    'AUX1': 1000  # Disarm at start
}

# Flags for subsystem activation
Flags = {
    'manual_override': False,
    'obstacle_detection': False,
    'change_altitude': False,
    'line_detection': False
}

# Lock for thread synchronization
lock = threading.Lock()

# -------------------- MSP and Serial Communication --------------------

# Initialize UART communication for RC commands and MSP requests (UART2)
ser_msp = serial.Serial('/dev/ttyUSB0', 115200, timeout=1)

# Define MSP header
MSP_HEADER = b'$M<'
MSP_HEADER_RESPONSE = b'$M>'

# Global variable to store arming disable flags
armingDisableFlags = 0

# Buffer to accumulate incoming serial data
data_buffer = b''

def create_msp_message(command, payload=b''):
    size = len(payload)
    checksum = 0
    checksum ^= size
    checksum ^= command
    for b in payload:
        checksum ^= b
    return MSP_HEADER + struct.pack('<BB', size, command) + payload + struct.pack('<B', checksum & 0xFF)

def send_msp_rc_command(channels):
    command = 200  # MSP_SET_RAW_RC
    payload = struct.pack('<8H', *channels)
    message = create_msp_message(command, payload)
    ser_msp.write(message)
    ser_msp.flush()  # Ensure data is sent promptly

def send_msp_status_ex_request():
    command = 150  # MSP_STATUS_EX
    message = create_msp_message(command)
    ser_msp.write(message)
    ser_msp.flush()

def process_serial_data(data):
    global data_buffer
    data_buffer += data

    while True:
        # Look for the MSP header in the data_buffer
        header_index = data_buffer.find(MSP_HEADER_RESPONSE)
        if header_index == -1:
            # No header found, keep the last few bytes in case header is split
            data_buffer = data_buffer[-2:]
            break
        else:
            # Remove data before the header
            if header_index > 0:
                data_buffer = data_buffer[header_index:]

            # Check if we have enough data for size, command, and checksum
            if len(data_buffer) < 6:
                # Not enough data yet
                break

            # Extract size and command
            size = data_buffer[3]
            command = data_buffer[4]

            total_length = 3 + 1 + 1 + size + 1  # header + size + command + payload + checksum

            if len(data_buffer) < total_length:
                # Not enough data yet
                break

            # Extract the full message
            message = data_buffer[:total_length]
            # Remove the message from the buffer
            data_buffer = data_buffer[total_length:]

            # Now process the message
            parse_msp_message(message)

def parse_msp_status_ex(message):
    global armingDisableFlags

    size = message[3]
    payload = message[5:5+size]

    if len(payload) == 22:
        try:
            # Unpack the 22-byte payload
            unpacked = struct.unpack('<HHHI B H H I H B', payload)
            cycleTime = unpacked[0]
            i2cErrorCounter = unpacked[1]
            activeSensors = unpacked[2]
            modeFlags = unpacked[3]
            profile = unpacked[4]
            systemLoad = unpacked[5]
            gyroCycleTime = unpacked[6]
            armingDisableFlags = unpacked[7]
            spare = unpacked[8]
            status = unpacked[9]

            # Interpret arming disable flags
            interpret_arming_disable_flags(armingDisableFlags)

            # Check arming status based on modeFlags
            if modeFlags & (1 << 0):
                print("Flight Controller is ARMED")
            else:
                print("Flight Controller is DISARMED")

        except struct.error as e:
            print(f"Struct unpacking error: {e}")
    else:
        print(f"Unexpected payload length: {len(payload)}")

def parse_msp_message(message):
    # message is a full MSP message starting with $M>
    if len(message) < 6:
        # Invalid message length
        return

    if message[:3] != MSP_HEADER_RESPONSE:
        return

    size = message[3]
    command = message[4]
    payload = message[5:5+size]
    checksum = message[5+size]

    # Verify checksum
    checksum_calc = 0
    checksum_calc ^= size
    checksum_calc ^= command
    for b in payload:
        checksum_calc ^= b
    checksum_calc &= 0xFF

    if checksum != checksum_calc:
        print("Checksum mismatch")
        return

    # Ignore empty responses for MSP_SET_RAW_RC
    if command == 200 and size == 0:
        # Silently ignore to avoid cluttering output
        return

    # Process known commands
    if command == 150:  # MSP_STATUS_EX
        parse_msp_status_ex(message)
    else:
        print(f"Received message with command {command}, but no handler is implemented for it.")

# Interpret arming disable flags
def interpret_arming_disable_flags(flags):
    arming_disable_flags = [
        (1 << 0, "ARMING_DISABLED_NO_GYRO"),
        # ... (include all flags as needed)
    ]

    if flags == 0:
        print("No arming disable flags are active.")
    else:
        print("Arming Disable Flags:")
        for flag_value, flag_name in arming_disable_flags:
            if flags & flag_value:
                print(f" - {flag_name}")

# -------------------- Obstacle Detection Subsystem --------------------

# GPIO setup for obstacle detection
GPIO.setmode(GPIO.BCM)
TRIG_OBSTACLE = 23
ECHO_OBSTACLE = 24
GPIO.setup(TRIG_OBSTACLE, GPIO.OUT)
GPIO.setup(ECHO_OBSTACLE, GPIO.IN)

def measure_distance_obstacle():
    """
    Measures the distance using an ultrasonic sensor for obstacle detection.
    Returns the distance in cm.
    """
    # Ensure the trigger is low
    GPIO.output(TRIG_OBSTACLE, False)
    time.sleep(0.002)  # Wait for 2 ms

    # Send a 10us pulse to trigger
    GPIO.output(TRIG_OBSTACLE, True)
    time.sleep(0.00001)  # 10 microseconds
    GPIO.output(TRIG_OBSTACLE, False)

    # Measure the time until the echo is received
    pulse_start = time.time()
    while GPIO.input(ECHO_OBSTACLE) == GPIO.LOW:
        pulse_start = time.time()

    pulse_end = time.time()
    while GPIO.input(ECHO_OBSTACLE) == GPIO.HIGH:
        pulse_end = time.time()

    # Calculate the pulse duration
    pulse_duration = pulse_end - pulse_start

    # Calculate the distance (Speed of sound is 34300 cm/s)
    distance = pulse_duration * 17150
    distance = round(distance, 2)

    return distance

def obstacle_detection_function():
    global RC_values, Flags, lock
    obstacle_timer = 0  # To track the duration of no obstacle detection
    obstacle_cleared = False  # Indicates if the obstacle has been cleared

    try:
        while True:
            # Measure distance to the nearest object
            dist = measure_distance_obstacle()
            print(f"Obstacle Detection - Measured Distance = {dist} cm")

            with lock:
                if 20 <= dist <= 50:
                    # Obstacle detected within 50 cm
                    Flags['obstacle_detection'] = True
                    # Set yaw, pitch, roll to neutral (hover)
                    RC_values['yaw'] = 1500
                    RC_values['pitch'] = 1500
                    RC_values['roll'] = 1500
                else:
                    # No obstacle detected
                    Flags['obstacle_detection'] = False

            # Obstacle cleared logic
            if dist > 50:
                if obstacle_cleared:
                    obstacle_timer += 0.5
                else:
                    obstacle_timer = 0.5
                    obstacle_cleared = True
            else:
                obstacle_timer = 0
                obstacle_cleared = False

            if obstacle_cleared and obstacle_timer >= 10:
                with lock:
                    Flags['obstacle_detection'] = False

            time.sleep(0.5)
    except KeyboardInterrupt:
        print("Obstacle detection stopped by user")
        GPIO.cleanup()

# -------------------- Altitude Stabilization Subsystem --------------------

# GPIO setup for altitude stabilization
TRIG_ALTITUDE = 22
ECHO_ALTITUDE = 27
GPIO.setup(TRIG_ALTITUDE, GPIO.OUT)
GPIO.setup(ECHO_ALTITUDE, GPIO.IN)

def measure_distance_altitude():
    # Ensure the trigger is low
    GPIO.output(TRIG_ALTITUDE, False)
    time.sleep(0.002)  # Wait for 2 ms

    # Send a 10us pulse to trigger
    GPIO.output(TRIG_ALTITUDE, True)
    time.sleep(0.00001)  # 10 microseconds
    GPIO.output(TRIG_ALTITUDE, False)

    # Measure the time until the echo is received
    pulse_start = time.time()
    while GPIO.input(ECHO_ALTITUDE) == GPIO.LOW:
        pulse_start = time.time()

    pulse_end = time.time()
    while GPIO.input(ECHO_ALTITUDE) == GPIO.HIGH:
        pulse_end = time.time()

    # Calculate the time difference
    pulse_duration = pulse_end - pulse_start

    # Calculate distance (Speed of sound is 34300 cm/s)
    distance = pulse_duration * 17150
    distance = round(distance, 2)

    return distance

def adjust_throttle(current_distance, target_altitude):
    """
    Adjusts the throttle based on the current altitude.
    """
    # Altitude control logic
    if current_distance < target_altitude - 10:  # Below the target altitude minus drift
        throttle = 1600  # Increase throttle to ascend
        altitude_reached = False
    elif current_distance > target_altitude + 10:  # Above the target altitude plus drift
        throttle = 1400  # Decrease throttle to descend
        altitude_reached = False
    else:
        throttle = 1500  # Maintain a neutral throttle to hover at the target altitude
        altitude_reached = True

    return throttle, altitude_reached

def altitude_stabilization_function():
    global RC_values, Flags, lock
    try:
        while True:
            if Flags['change_altitude']:
                target_altitude = Flags.get('target_altitude', 100)  # Default to 100 cm if not set

                while True:
                    current_altitude = measure_distance_altitude()
                    print(f"Altitude Stabilization - Current Altitude: {current_altitude} cm")
                    throttle, altitude_reached = adjust_throttle(current_altitude, target_altitude)
                    with lock:
                        RC_values['throttle'] = throttle
                        if altitude_reached:
                            Flags['change_altitude'] = False
                            print("Altitude reached.")
                            break
                        else:
                            print("Adjusting altitude...")
                    time.sleep(0.5)
            else:
                time.sleep(0.1)
    except KeyboardInterrupt:
        print("Altitude stabilization stopped by user")
        GPIO.cleanup()

# -------------------- Line Detection Subsystem --------------------

def determine_yaw(cx, img_center_x):
    dx = cx - img_center_x  # Horizontal distance
    # Calculate yaw adjustments based on dx (yaw changes to rotate the drone)
    yaw = 1500 + int(dx * 0.1)  # Adjust the scaling factor as needed (1500 is neutral yaw)
    # Constrain yaw to valid RC values (1000 - 2000)
    yaw = max(1000, min(2000, yaw))
    return yaw

def check_line_orientation(contour):
    x, y, w, h = cv2.boundingRect(contour)
    # Check if it's a vertical line (height > width) or horizontal (perpendicular) line (width > height)
    if h > w:
        return "vertical"
    elif w > h:
        return "perpendicular"
    else:
        return "unknown"

def capture_image(filename='image.jpg'):
    # Capture the image using libcamera
    run(["libcamera-still", "-o", filename, "--nopreview", "--timeout", "1"], check=True)

def line_detection_function():
    global RC_values, Flags, lock
    last_parallel_line_time = 0
    parallel_line_cooldown = 2  # Time in seconds to ignore parallel lines after detection

    try:
        while True:
            if Flags['line_detection']:
                capture_image('image.jpg')  # Capture an image every 0.5 seconds
                image = cv2.imread('image.jpg')

                if image is None:
                    print("Error: Image not loaded. Please check the file path and try again.")
                    continue
                else:
                    # Rotate the image 180 degrees to correct the orientation
                    image = cv2.rotate(image, cv2.ROTATE_180)

                    # Zoom out by resizing the image (e.g., to 25% of its original size)
                    scale_percent = 25  # Scale to 25% of the original size
                    width = int(image.shape[1] * scale_percent / 100)
                    height = int(image.shape[0] * scale_percent / 100)
                    dim = (width, height)

                    # Calculate the center of the bottom edge of the image
                    img_center_x = width // 2  # Midpoint of the bottom edge (x-coordinate)

                    # Resize the image
                    resized_image = cv2.resize(image, dim)

                    # Convert the resized image to grayscale
                    grayscale_image = cv2.cvtColor(resized_image, cv2.COLOR_BGR2GRAY)

                    # Apply a manual threshold to focus on the darkest/high contrast areas
                    manual_threshold = 40  # Adjust this value depending on the contrast of the line
                    _, binary_image = cv2.threshold(grayscale_image, manual_threshold, 255, cv2.THRESH_BINARY_INV)

                    # Apply morphological operations to connect broken parts of the line
                    kernel = np.ones((7, 7), np.uint8)
                    morph_image = cv2.morphologyEx(binary_image, cv2.MORPH_CLOSE, kernel)
                    morph_image = cv2.dilate(morph_image, kernel, iterations=1)

                    # Detect the line using contours
                    contours, _ = cv2.findContours(morph_image, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                    if contours:
                        min_contour_area = 20  # Minimum area threshold
                        filtered_contours = [cnt for cnt in contours if cv2.contourArea(cnt) > min_contour_area]

                        for contour in filtered_contours:
                            orientation = check_line_orientation(contour)

                            # Check if enough time has passed since last parallel line detection
                            current_time = time.time()

                            if orientation == "vertical":
                                # If a vertical line is detected, continue tracking
                                print("Line Detection - Vertical line detected.")

                                # Calculate the center of the vertical contour
                                M = cv2.moments(contour)
                                if M['m00'] != 0:
                                    cx = int(M['m10'] / M['m00'])
                                else:
                                    cx = 0

                                # Calculate required yaw
                                yaw = determine_yaw(cx, img_center_x)

                                # Set pitch and roll to constant values
                                pitch = 1600  # Constant forward pitch
                                roll = 1500   # Neutral roll

                                with lock:
                                    RC_values['yaw'] = yaw
                                    RC_values['pitch'] = pitch
                                    RC_values['roll'] = roll
                                    RC_values['AUX1'] = 1500  # Keep drone armed

                            elif orientation == "perpendicular" and (current_time - last_parallel_line_time) > parallel_line_cooldown:
                                # If a perpendicular line is detected and cooldown has passed, hover for 5 seconds
                                print("Line Detection - Perpendicular line detected. Hovering for 5 seconds.")

                                with lock:
                                    RC_values['pitch'] = 1500
                                    RC_values['roll'] = 1500
                                    RC_values['yaw'] = 1500  # Neutral
                                time.sleep(5)  # Hold position for 5 seconds
                                print("Resuming after 5 seconds.")

                                # Update the time of last parallel line detection
                                last_parallel_line_time = current_time

                    else:
                        # No line detected, set all values to neutral for 30 seconds, then disarm
                        print("Line Detection - No line detected. Setting neutral values for 30 seconds.")

                        with lock:
                            RC_values['pitch'] = 1500
                            RC_values['roll'] = 1500
                            RC_values['yaw'] = 1500
                            RC_values['AUX1'] = 1500  # Keep drone armed

                        time.sleep(30)  # Hover for 30 seconds

                        with lock:
                            RC_values['pitch'] = 0
                            RC_values['roll'] = 0
                            RC_values['yaw'] = 0
                            RC_values['AUX1'] = 1000  # Disarm
                        print("RC values set to 0. Disarmed due to no line detection.")
                        with lock:
                            Flags['line_detection'] = False  # Stop line detection

                # Wait for 0.5 seconds before capturing the next image
                time.sleep(0.5)
            else:
                time.sleep(0.1)
    except KeyboardInterrupt:
        print("Line detection stopped by user")

# -------------------- Manual Override Subsystem --------------------

def emergency_stop():
    global RC_values, Flags, lock
    with lock:
        RC_values['pitch'] = 1500
        RC_values['roll'] = 1500
        RC_values['yaw'] = 1500
        RC_values['throttle'] = 1000  # Minimum throttle
        RC_values['AUX1'] = 1000  # Disarm
        Flags['manual_override'] = False  # Deactivate manual override
    print("Emergency Stop Activated")

def manual_override_function():
    # The manual override logic is handled by the input thread
    pass

# -------------------- Input Handling --------------------

def input_thread_function():
    global RC_values, Flags, lock
    try:
        while True:
            # Use select to check for input without blocking
            if select.select([sys.stdin], [], [], 0)[0]:
                user_input = sys.stdin.readline().strip()
                if user_input == '':
                    continue  # Ignore empty input
                with lock:
                    # Handle input commands
                    if user_input.lower() == 'esc':
                        emergency_stop()
                        break  # Exit the input thread

                    elif user_input.lower() == '1':
                        # Activate altitude stabilization
                        Flags['change_altitude'] = True
                        # Prompt for target altitude
                        print("Enter the desired altitude in cm:")
                        target_altitude = sys.stdin.readline().strip()
                        try:
                            target_altitude = float(target_altitude)
                            Flags['target_altitude'] = target_altitude
                        except ValueError:
                            print("Invalid altitude value.")
                            Flags['change_altitude'] = False

                    elif user_input.lower() == '2':
                        # Activate line detection
                        Flags['line_detection'] = True
                        Flags['manual_override'] = False  # Deactivate manual override

                    elif user_input.lower() in ['w', 'a', 's', 'd', 'up', 'down']:
                        # Activate manual override
                        Flags['manual_override'] = True
                        Flags['line_detection'] = False  # Deactivate line detection

                        # Update RC values based on input
                        if user_input.lower() == 'a':
                            RC_values['yaw'] = 1400
                        elif user_input.lower() == 'd':
                            RC_values['yaw'] = 1600
                        elif user_input.lower() == 'up':
                            RC_values['throttle'] = 1600
                        elif user_input.lower() == 'down':
                            RC_values['throttle'] = 1400
                        else:
                            # For 'w' and 's', you can define actions if needed
                            pass
                    else:
                        # Reset RC values to neutral if no valid key is pressed
                        if Flags['manual_override']:
                            RC_values['yaw'] = 1500
                            RC_values['throttle'] = 1500

            else:
                # No input, sleep briefly to avoid busy-waiting
                time.sleep(0.1)
    except KeyboardInterrupt:
        print("Input thread stopped by user")

# -------------------- Main Function --------------------

def main():
    global RC_values, Flags, lock, data_buffer

    # Start threads for each subsystem
    obstacle_thread = threading.Thread(target=obstacle_detection_function)
    altitude_thread = threading.Thread(target=altitude_stabilization_function)
    line_thread = threading.Thread(target=line_detection_function)
    input_thread = threading.Thread(target=input_thread_function)

    # Start threads
    obstacle_thread.start()
    altitude_thread.start()
    line_thread.start()
    input_thread.start()

    # Initialize arming
    channels = [1500] * 8  # Initialize all channels to mid-point (1500)
    channels[0] = RC_values['throttle']     # Throttle
    channels[1] = RC_values['roll']         # Roll
    channels[2] = RC_values['pitch']        # Pitch
    channels[3] = RC_values['yaw']          # Yaw
    channels[4] = RC_values['AUX1']         # AUX1 (Arm/Disarm)
    channels[5] = 1500                      # AUX2 (Mode switches if needed)
    channels[6] = 1000                      # AUX3
    channels[7] = 1000                      # AUX4

    print("Disarming and setting RC values to zero...")
    data_buffer = b''

    # Send RC commands with arm switch off for 2 seconds
    start_time = time.time()
    while time.time() - start_time < 2:
        with lock:
            # Update channels with current RC_values
            channels[0] = 1000  # Minimum throttle
            channels[1] = 1500  # Roll
            channels[2] = 1500  # Pitch
            channels[3] = 1500  # Yaw
            channels[4] = 1000  # AUX1 (Disarm)
        send_msp_rc_command(channels)
        time.sleep(0.02)  # Maintain loop rate of approximately 50Hz

    print("Arming the drone...")
    # Set AUX1 to 1900 to arm
    with lock:
        RC_values['AUX1'] = 1900

    last_status_time = 0
    last_telemetry_time = 0

    try:
        while True:
            # Send RC commands
            with lock:
                # Update channels with current RC_values
                channels[0] = RC_values['throttle']
                channels[1] = RC_values['roll']
                channels[2] = RC_values['pitch']
                channels[3] = RC_values['yaw']
                channels[4] = RC_values['AUX1']
                # You can update other channels if needed

            send_msp_rc_command(channels)

            # Read any available data from the serial port
            data = ser_msp.read(ser_msp.in_waiting or 1)
            if data:
                process_serial_data(data)

            # Send MSP_STATUS_EX request every 0.2 seconds
            current_time = time.time()
            if current_time - last_status_time >= 0.2:
                send_msp_status_ex_request()
                last_status_time = current_time

            time.sleep(0.02)  # Maintain loop rate of approximately 50Hz

    except KeyboardInterrupt:
        print("Main loop stopped by user. Disarming before exiting...")
        # Set arm switch to "off"
        with lock:
            RC_values['AUX1'] = 1000  # Disarm
            RC_values['throttle'] = 1000  # Minimum throttle

        # Send RC commands with arm switch off for 0.5 seconds
        disarm_time = time.time()
        while time.time() - disarm_time < 0.5:
            with lock:
                channels[0] = RC_values['throttle']
                channels[1] = RC_values['roll']
                channels[2] = RC_values['pitch']
                channels[3] = RC_values['yaw']
                channels[4] = RC_values['AUX1']
            send_msp_rc_command(channels)
            time.sleep(0.02)

        print("Disarmed. Exiting...")
        ser_msp.close()
        GPIO.cleanup()

if __name__ == "__main__":
    main()
